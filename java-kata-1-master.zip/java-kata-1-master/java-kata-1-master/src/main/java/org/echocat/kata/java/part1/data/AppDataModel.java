package org.echocat.kata.java.part1.data;

import lombok.Builder;
import lombok.Data;
import org.echocat.kata.java.part1.model.CsvBean;

import java.util.List;

@Data
@Builder
public class AppDataModel {
    private List<CsvBean> bookList;
    private List<CsvBean> magazineList;
    private List<CsvBean> authorList;
}
