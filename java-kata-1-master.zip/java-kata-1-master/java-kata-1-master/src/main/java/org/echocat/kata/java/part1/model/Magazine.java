package org.echocat.kata.java.part1.model;

import com.opencsv.bean.CsvBindByName;
import com.opencsv.bean.CsvBindByPosition;
import com.opencsv.bean.CsvDate;
import lombok.*;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
@Builder
public class Magazine extends CsvBean {

    @CsvBindByName(column = "title")
    @CsvBindByPosition(position = 0)
    private String title;

    @CsvBindByPosition(position = 1)
    private String isbn;

    @CsvBindByPosition(position = 2)
    private String authors;

    @CsvBindByPosition(position = 3)
    @CsvDate(value = "dd.MM.yyyy")
    private LocalDate publishedAt;

}
