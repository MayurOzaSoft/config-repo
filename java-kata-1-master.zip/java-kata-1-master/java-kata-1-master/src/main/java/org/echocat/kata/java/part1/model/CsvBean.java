package org.echocat.kata.java.part1.model;

public class CsvBean {
}
