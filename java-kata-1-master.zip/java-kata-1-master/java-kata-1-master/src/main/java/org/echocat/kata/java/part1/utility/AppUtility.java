package org.echocat.kata.java.part1.utility;

import org.echocat.kata.java.part1.data.AppDataModel;
import org.echocat.kata.java.part1.data.AppEnum;
import org.echocat.kata.java.part1.mapper.BookMagazineMapper;
import org.echocat.kata.java.part1.model.*;
import org.mapstruct.factory.Mappers;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class AppUtility {

    private static final BookMagazineMapper bookMagazineMapper = Mappers.getMapper(BookMagazineMapper.class);

    public static Optional<BookMagazine> findByIsbn(AppDataModel appDataModel, Class clazz, String isbn) {
        BookMagazine bookMagazine = new BookMagazine();

        AppEnum type = AppEnum.get(clazz.getName());
        switch (type) {
            case Books:
                Optional<CsvBean> optionalBookCsvBean = appDataModel.getBookList().stream()
                        .filter(csvBean -> ((Book) csvBean).getIsbn().equals(isbn))
                        .findFirst();

                if (optionalBookCsvBean.isPresent()) {
                    Book book = (Book) optionalBookCsvBean.get();
                    bookMagazine = bookMagazineMapper.fromBook(book);
                }

                break;
            case Magazines:
                Optional<CsvBean> optionalMagazineCsvBean = appDataModel.getMagazineList().stream()
                        .filter(csvBean -> ((Magazine) csvBean).getIsbn().equals(isbn))
                        .findFirst();

                if (optionalMagazineCsvBean.isPresent()) {
                    Magazine magazine = (Magazine) optionalMagazineCsvBean.get();
                    bookMagazine = bookMagazineMapper.fromMagazine(magazine);
                }

                break;
        }

        return bookMagazine == null ? Optional.empty() : Optional.of(bookMagazine);
    }

    public static List<BookMagazine> findByEmail(AppDataModel appDataModel, String email) {

        Optional<CsvBean> optionalAuthorCsvBean = appDataModel.getAuthorList().stream()
                .filter(csvBean -> ((Author) csvBean).getEmail().equals(email))
                .findFirst();

        if (optionalAuthorCsvBean.isEmpty()) return new ArrayList<>();

        return mapBookMagazine(appDataModel, email);
    }

    private static List<BookMagazine> mapBookMagazine(AppDataModel appDataModel, String email) {

        List<Book> books = appDataModel.getBookList()
                .stream()
                .flatMap(select(Book.class))
                .filter(book -> book.getAuthors().contains(email))
                .collect(Collectors.toList());

        List<BookMagazine> bookMagazineList = books.stream().map(bookMagazineMapper::fromBook).collect(Collectors.toList());

        List<Magazine> magazines = appDataModel.getMagazineList()
                .stream()
                .flatMap(select(Magazine.class))
                .filter(book -> book.getAuthors().contains(email))
                .collect(Collectors.toList());

        bookMagazineList.addAll(magazines.stream().map(bookMagazineMapper::fromMagazine).collect(Collectors.toList()));

        return bookMagazineList;
    }

    public static List<BookMagazine> findAll(AppDataModel appDataModel) {
        List<BookMagazine> bookMagazineList = new ArrayList<>();
        BookMagazineMapper bookMagazineMapper = Mappers.getMapper(BookMagazineMapper.class);

        for (CsvBean csvBeanBook : appDataModel.getBookList()) {
            Book book = (Book) csvBeanBook;
            bookMagazineList.add(bookMagazineMapper.fromBook(book));
        }

        for (CsvBean csvBeanMagazine : appDataModel.getMagazineList()) {
            Magazine magazine = (Magazine) csvBeanMagazine;
            bookMagazineList.add(bookMagazineMapper.fromMagazine(magazine));
        }

        // bookMagazineList.forEach(System.out::println);

        return bookMagazineList;
    }

    private static <T, R> Function<T, Stream<R>> select(Class<R> clazz) {
        return e -> clazz.isInstance(e) ? Stream.of(clazz.cast(e)) : null;
    }

    public static String[][] transformObjectToStringArray(List<CsvBean> beans, String[] columns, Class clazz) {
        String[][] array = new String[beans.size() + 1][columns.length];

        // column Mapping
        array[0] = columns;

        AppEnum type = AppEnum.get(clazz.getName());
        switch (type) {
            case Books:
                for (int i = 0; i < beans.size(); i++) {
                    Book row = (Book) beans.get(i);
                    String[] rowString = new String[columns.length];
                    rowString[0] = row.getTitle();
                    rowString[1] = row.getIsbn();
                    rowString[2] = row.getAuthors();
                    rowString[3] = row.getDescription();
                    array[i + 1] = rowString;
                }
                break;
            case Magazines:
                for (int i = 0; i < beans.size(); i++) {
                    Magazine row = (Magazine) beans.get(i);
                    String[] rowString = new String[columns.length];
                    rowString[0] = row.getTitle();
                    rowString[1] = row.getIsbn();
                    rowString[2] = row.getAuthors();
                    rowString[3] = row.getPublishedAt().toString();
                    array[i + 1] = rowString;
                }

                break;
            case Authors:
                for (int i = 0; i < beans.size(); i++) {
                    Author row = (Author) beans.get(i);
                    String[] rowString = new String[columns.length];
                    rowString[0] = row.getEmail();
                    rowString[1] = row.getFirstName();
                    rowString[2] = row.getLastName();
                    array[i + 1] = rowString;
                }
                break;
        }

        return array;
    }

    public static String[][] transformMapperObjectToStringArray(List<BookMagazine> beans, String[] columns) {
        String[][] array = new String[beans.size() + 1][columns.length];
        array[0] = columns;

        for (int i = 0; i < beans.size(); i++) {
            BookMagazine row = beans.get(i);
            String[] rowString = new String[columns.length];
            rowString[0] = row.getTitle();
            rowString[1] = row.getIsbn();
            rowString[2] = row.getAuthors();
            rowString[3] = row.getDescription() == null ? "" : row.getDescription();
            rowString[4] = row.getPublishedAt() == null ? "" : row.getPublishedAt().toString();
            array[i + 1] = rowString;
        }

        return array;
    }
}
