package org.echocat.kata.java.part1.model;

import lombok.*;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@EqualsAndHashCode
public class BookMagazine {
    private String title;
    private String isbn;
    private String authors;
    private String description;
    private LocalDate publishedAt;
}
