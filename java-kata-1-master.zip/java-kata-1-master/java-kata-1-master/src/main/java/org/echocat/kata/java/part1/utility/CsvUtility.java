package org.echocat.kata.java.part1.utility;

import java.io.IOException;
import java.io.Reader;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class CsvUtility {

    private final static String DATA_PATH = "org/echocat/kata/java/part1/data/";

    public static URI getURI(String csvName) throws URISyntaxException {
        return ClassLoader.getSystemResource(DATA_PATH + csvName).toURI();
    }

    public static Reader getReader(String csvName) throws URISyntaxException, IOException {
        return Files.newBufferedReader(Paths.get(CsvUtility.getURI(csvName)));
    }
}
