package org.echocat.kata.java.part1.data;

import org.echocat.kata.java.part1.model.Author;
import org.echocat.kata.java.part1.model.Book;
import org.echocat.kata.java.part1.model.Magazine;

import java.util.Collections;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public enum AppEnum {

    Books(Book.class.getName()),
    Authors(Author.class.getName()),
    Magazines(Magazine.class.getName());

    private final String refClassname;
    private static final Map<String, AppEnum> ENUM_MAP;

    AppEnum(String refClassname) {
        this.refClassname = refClassname;
    }

    static {
        Map<String, AppEnum> map = new ConcurrentHashMap<>();
        for (AppEnum instance : AppEnum.values()) {
            map.put(instance.refClassname, instance);
        }
        ENUM_MAP = Collections.unmodifiableMap(map);
    }

    public static AppEnum get(String name) {
        return ENUM_MAP.get(name);
    }
}