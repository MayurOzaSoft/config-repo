package org.echocat.kata.java.part1.mapper;

import org.echocat.kata.java.part1.model.Book;
import org.echocat.kata.java.part1.model.BookMagazine;
import org.echocat.kata.java.part1.model.Magazine;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper
public interface BookMagazineMapper {
    @Mapping(source = "book.title", target = "title")
    @Mapping(source = "book.isbn", target = "isbn")
    @Mapping(source = "book.authors", target = "authors")
    @Mapping(source = "book.description", target = "description")
    BookMagazine fromBook(Book book);
    @Mapping(source = "magazine.title", target = "title")
    @Mapping(source = "magazine.isbn", target = "isbn")
    @Mapping(source = "magazine.authors", target = "authors")
    @Mapping(source = "magazine.publishedAt", target = "publishedAt")
    BookMagazine fromMagazine(Magazine magazine);
}