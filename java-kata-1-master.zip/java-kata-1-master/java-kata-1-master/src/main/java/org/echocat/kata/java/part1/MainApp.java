package org.echocat.kata.java.part1;

import org.echocat.kata.java.part1.data.AppDataModel;
import org.echocat.kata.java.part1.model.*;
import org.echocat.kata.java.part1.reader.CsvReader;
import org.echocat.kata.java.part1.utility.AppUtility;
import org.echocat.kata.java.part1.utility.CsvUtility;
import org.echocat.kata.java.part1.utility.PrintUtility;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class MainApp {

    public static void main(String[] args) throws Exception {
        System.out.println(getHelloWorldText());
        System.out.println("\n-------------------------------------------------------");

        System.out.println("\nPrint all from authors.csv");

        // Read Author
        List<CsvBean> authors = CsvReader.csvToBeanBuilder(CsvUtility.getReader("authors.csv"), Author.class);
        String[] authorsColumn = new String[]{ "email", "firstname", "lastname"};
        PrintUtility.print(AppUtility.transformObjectToStringArray(authors, authorsColumn, Author.class));

        System.out.println("\nPrint all from books.csv");

        // Read Book
        List<CsvBean> books = CsvReader.csvToBeanBuilder(CsvUtility.getReader("books.csv"), Book.class);
        String[] booksColumn = new String[]{ "title", "isbn", "authors", "description"};
        PrintUtility.print(AppUtility.transformObjectToStringArray(books, booksColumn, Book.class));

        System.out.println("\nPrint all from magazines.csv");

        // Read Magazine
        List<CsvBean> magazines = CsvReader.csvToBeanBuilder(CsvUtility.getReader("magazines.csv"), Magazine.class);
        String[] magazinesColumn = new String[]{ "title", "isbn", "authors", "publishedAt"};
        PrintUtility.print(AppUtility.transformObjectToStringArray(magazines, magazinesColumn, Magazine.class));

        // Map Model
        AppDataModel appDataModel = AppDataModel.builder()
                .authorList(authors)
                .bookList(books)
                .magazineList(magazines)
                .build();

        System.out.println("\nPrint all Books and Magazines");

        // Print out all books and magazines
        List<BookMagazine> allBookMagazines = AppUtility.findAll(appDataModel);
        String[] allBookMagazinesColumn = new String[]{ "title", "isbn", "authors", "description", "publishedAt"};
        PrintUtility.print(AppUtility.transformMapperObjectToStringArray(allBookMagazines, allBookMagazinesColumn));

        System.out.println("\nBooks by isbn");

        // Find a book or magazine by its isbn
        Optional<BookMagazine> book = AppUtility.findByIsbn(appDataModel, Book.class, "2145-8548-3325");
        if(book.isPresent()){
            List<BookMagazine> bookMagazines = new ArrayList<>();
            bookMagazines.add(book.get());
            PrintUtility.print(AppUtility.transformMapperObjectToStringArray(bookMagazines, allBookMagazinesColumn));
        } else {
            System.out.println("No Data Found for given ISBN");
        }

        System.out.println("\nMagazines by isbn");
        Optional<BookMagazine> magazine = AppUtility.findByIsbn(appDataModel, Magazine.class, "2547-8548-2541");
        if(magazine.isPresent()){
            List<BookMagazine> bookMagazines = new ArrayList<>();
            bookMagazines.add(magazine.get());
            PrintUtility.print(AppUtility.transformMapperObjectToStringArray(bookMagazines, allBookMagazinesColumn));
        } else {
            System.out.println("No Data Found for given ISBN");
        }

        System.out.println("\nBooks and Magazines by authors email");

        // Find all books and magazines by their authors email
        List<BookMagazine> bookMagazines = AppUtility.findByEmail(appDataModel, "null-walter@echocat.org");
        PrintUtility.print(AppUtility.transformMapperObjectToStringArray(bookMagazines, allBookMagazinesColumn));

        System.out.println("\nSort by title");

        // Sort by title
        List<BookMagazine> sortedList = allBookMagazines.stream()
                .sorted(Comparator.comparing(BookMagazine::getTitle))
                .collect(Collectors.toList());
        PrintUtility.print(AppUtility.transformMapperObjectToStringArray(sortedList, allBookMagazinesColumn));

    }

    protected static String getHelloWorldText() {
        return "Hello world!";
    }

}
