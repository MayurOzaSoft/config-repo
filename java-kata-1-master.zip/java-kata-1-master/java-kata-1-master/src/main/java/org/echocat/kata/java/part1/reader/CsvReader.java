package org.echocat.kata.java.part1.reader;

import com.opencsv.bean.CsvToBean;
import com.opencsv.bean.CsvToBeanBuilder;
import org.echocat.kata.java.part1.model.CsvBean;
import org.echocat.kata.java.part1.utility.CsvTransfer;

import java.io.Reader;
import java.util.List;

public class CsvReader {

    public static List<CsvBean> csvToBeanBuilder(Reader reader, Class clazz) {
        try {
            CsvTransfer csvTransfer = new CsvTransfer();

            CsvToBean cb = new CsvToBeanBuilder(reader)
                    .withType(clazz)
                    .withSeparator(';')
                    .withSkipLines(1)
                    .build();

            csvTransfer.setCsvList(cb.parse());

            reader.close();

           return csvTransfer.getCsvList();

        } catch (Exception e){
            throw new RuntimeException(e.getMessage());
        }
    }

}
