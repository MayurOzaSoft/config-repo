package org.echocat.kata.java.part1.model;

import com.opencsv.bean.CsvBindByName;
import com.opencsv.bean.CsvBindByPosition;
import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
@Builder
public class Book extends CsvBean {
    @CsvBindByName(column = "title")
    @CsvBindByPosition(position = 0)
    private String title;

    @CsvBindByPosition(position = 1)
    private String isbn;

    @CsvBindByPosition(position = 2)
    private String authors;

    @CsvBindByPosition(position = 3)
    private String description;

}
